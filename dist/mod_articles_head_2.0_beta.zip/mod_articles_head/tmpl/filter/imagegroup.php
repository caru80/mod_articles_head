<?php
/**
 * @package        HEAD. Article Module
 * @version        1.8.5
 * 
 * @author         Carsten Ruppert <webmaster@headmarketing.de>
 * @link           https://www.headmarketing.de
 * @copyright      Copyright © 2018 HEAD. MARKETING GmbH All Rights Reserved
 * @license        http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

/**
 * @copyright    Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license      GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
/*echo "<code><pre>";
var_dump($oneFilter);
echo "</pre></code>";*/
?>
<div class="mod-intro-filter-group imagegroup"<?php echo $oneFilter->group_data;?>>
	<?php
		if($oneFilter->label != ''):
	?>
			<div class="filter-group-label">
				<?php echo $oneFilter->label;?>
			</div>
	<?php
		endif;
	?>
	<div class="filter-<?php echo $oneFilter->type;?>">
	
		<?php
			// „Alle” (Diesen Filter zurücksetzen):
			if(!$oneFilter->multiple && !$oneFilter->hide_all):
		?>
				<label class="<?php echo $oneFilter->default_value === null ? ' active' : '';?>">
					<input type="radio" name="<?php echo $oneFilter->field_name;?>" value="" /> <?php echo JText::_('JALL');?>
				</label>
		<?php
			endif;
		?>

		<?php
			foreach($oneFilter->options as $x => $option):
		?>
				<label data-so="fadeIn" data-sodelay="<?php echo $x * 100;?>" id="filter-opt-<?php echo $option->raw_value;?>" class="<?php echo $option->raw_value == $oneFilter->default_value ? ' active' : '';?>">
					<input 
						type="<?php echo $oneFilter->multiple ? 'checkbox' : 'radio';?>" 
						value="<?php echo $option->raw_value;?>" 
						name="<?php echo $oneFilter->field_name;?>" 
					/> 
					<span class="filter-image"></span>
					<span class="filter-label">
						<span class="filter-label-text">
							<?php echo $option->title;?>
						</span>
					</span>
					<?php if($oneFilter->show_items): ?>
						<span class="badge"><?php echo $option->items_count;?></span>
					<?php endif; ?>
				</label>
		<?php
			endforeach;
		?>
	</div>
	<script>
		<?php // Die Buttons der btn-group inaktiv machen, wenn die Filter zurückgesetzt werden. ?>
		/*
		(function($) {
			$(function() {
				$('#mod-intro-<?php echo $module->id;?>').modintroajax().module.on('resetFilters', function() 
				{
					$(this).find('.btn-group .btn').each(function() {
						if($(this).hasClass('active')) {
							$(this).button('toggle'); <?php // Twitter Bootstrap! ?>
						}
					});
				});
			});
		})(jQuery);
		*/
	</script>
	<?php
		if(!$oneFilter->multiple):
	?>
			<script>
				(function($)
				{
					$('[name="<?php echo $oneFilter->field_name;?>"]', '#mod-intro-<?php echo $module->id;?>').on('change', function()
					{
						$('#mod-intro-<?php echo $module->id;?>').modintroajax().applyFilterGroups();

						$(this).parent().parent().find('.active').removeClass('active');
						$(this).parent().addClass('active');

					});
				})(jQuery);
			</script>
	<?php
		endif;
	?>
</div>
